<?php
/*
*@package Auto-postingToTelegramChannel
*/
function deactivete() {

  flush_rewrite_rules();
}
