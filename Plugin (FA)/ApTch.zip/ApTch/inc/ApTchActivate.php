<?php
/*
*@package Auto-postingToTelegramChannel
*/

function activete() {
  flush_rewrite_rules();
}
